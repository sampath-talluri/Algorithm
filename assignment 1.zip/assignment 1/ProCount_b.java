import java.util.Scanner;
class TestCount
{
 public static void CountAlogrithm(int x[],int n)
{
int c=0;
int i=1;
c++;
  x[i]=x[i]+2; i=i+2;
  c=c+2;

i=1;
c++;
while(i<=n/2)
{
c++;
x[i]=x[i]+x[i+1];
c=c+2;
 i=i+1;
c++;
}
System.out.println("Step Count of statements Execution:"+c);
}
}
class ProCount_b
{
 public static void main(String args[])
 {
  Scanner cin=new Scanner(System.in);
  System.out.print("Enter the n value:");
  int n=cin.nextInt();
  int x[]=new int[n];
   TestCount.CountAlogrithm(x,n);
}
}