import java.util.*;
import java.util.concurrent.*;

class  Matrix
{
 public static void main(String args[])
 {
   int a[][]=new int[3][3];
   int b[][]=new int[3][3];
   int c[][]=new int[3][3];

   int i,j,k;
   Scanner cin=new Scanner(System.in);
   System.out.println("Enter 1st 3 x 3 matrix:");
   for(i=0;i<3;i++)
   for(j=0;j<3;j++)
     a[i][j]=cin.nextInt();

   System.out.println("Enter 2nd 3 x 3 matrix:");
   for(i=0;i<3;i++)
   for(j=0;j<3;j++)
     b[i][j]=cin.nextInt();


/*resultant matrix*/
long starttime=System.nanoTime();
   for(i=0;i<3;i++)
   {
     for(j=0;j<3;j++)
     {
      c[i][j]=0;
      for(k=0;k<3;k++)
      {
        c[i][j]+=a[i][k]*b[k][j];
       }
     }
 }
long endtime=System.nanoTime();
long timetaken=endtime-starttime;
System.out.println("============================");
System.out.println("Process Starting time :"+starttime+" ns ");
System.out.println("Process Ending time :"+endtime+" ns ");
System.out.println("Execution time in nanoseconds :"+timetaken+" ns ");
System.out.println("============================");

System.out.println("Resultant matrix:");
for(i=0;i<3;i++)
{
  for(j=0;j<3;j++)
  {
    System.out.print(c[i][j]+"\t");
  }
System.out.println("\n");
}
}
}