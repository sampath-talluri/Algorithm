import java.util.*;
import java.util.concurrent.*;

class  Matrix1
{
 public static void main(String args[])
 {
int a[][]={ {1,2,3},{4,5,6}, {7,8,9}};
int b[][]={ {10,20,30},{40,50,60},{70,80,90}};
int c[][]=new int[3][3];  
int i,j,k;

/*resultant matrix*/
long starttime=System.nanoTime();
   for(i=0;i<3;i++)
   {
     for(j=0;j<3;j++)
     {
      c[i][j]=0;
      for(k=0;k<3;k++)
      {
        c[i][j]+=a[i][k]*b[k][j];
       }
     }
 }
long endtime=System.nanoTime();
long timetaken=endtime-starttime;
System.out.println("============================");
System.out.println("Process Starting time :"+starttime+" ns ");
System.out.println("Process Ending time :"+endtime+" ns ");
System.out.println("Execution time in nanoseconds :"+timetaken+" ns ");
System.out.println("============================");

System.out.println("Resultant matrix:");
for(i=0;i<3;i++)
{
  for(j=0;j<3;j++)
  {
    System.out.print(c[i][j]+"\t");
  }
System.out.println("\n");
}
}
}